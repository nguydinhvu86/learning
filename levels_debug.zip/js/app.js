// app.js - Main Application Controller

const App = {
  currentLevel: 1,
  currentMode: 'mindmap',
  currentCategory: null,
  currentWordIndex: 0,
  studyQueue: [],
  masteredWords: new Set(JSON.parse(localStorage.getItem('hsk_mastered') || '[]')),
  showPinyin: true,
  showMeaning: false,

  data: {
    1: typeof HSK1_DATA !== 'undefined' ? HSK1_DATA : null,
    2: typeof HSK2_DATA !== 'undefined' ? HSK2_DATA : null,
    3: typeof HSK3_DATA !== 'undefined' ? HSK3_DATA : null,
    4: typeof HSK4_DATA !== 'undefined' ? HSK4_DATA : null,
  },

  init() {
    this.bindEvents();
    this.selectLevel(1);
    this.selectMode('mindmap');
    this.updateStats();
  },

  bindEvents() {
    // Level buttons
    document.querySelectorAll('.level-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        this.selectLevel(parseInt(btn.dataset.level));
        if (window.innerWidth <= 768) this.toggleSidebar(false);
      });
    });
    // Mode tabs
    document.querySelectorAll('.mode-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        this.selectMode(tab.dataset.mode);
        // Optional: Scroll tabs into view if needed
      });
    });
    // Search
    const searchInput = document.getElementById('search-input');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => this.handleSearch(e.target.value));
    }
    // Toggle Sidebar for mobile
    const menuToggle = document.getElementById('menu-toggle');
    if (menuToggle) {
      menuToggle.addEventListener('click', () => this.toggleSidebar(true));
    }
  },

  toggleSidebar(show) {
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.getElementById('sidebar-overlay');
    if (sidebar && overlay) {
      if (show) {
        sidebar.classList.add('active');
        overlay.classList.add('active');
      } else {
        sidebar.classList.remove('active');
        overlay.classList.remove('active');
      }
    }
  },

  selectLevel(level) {
    this.currentLevel = level;
    this.currentCategory = null;
    document.querySelectorAll('.level-btn').forEach(btn => {
      btn.classList.toggle('active', parseInt(btn.dataset.level) === level);
    });
    const levelColors = { 1: '#4CAF50', 2: '#2196F3', 3: '#9C27B0', 4: '#FF9800' };
    document.documentElement.style.setProperty('--accent-color', levelColors[level]);
    this.renderCurrentMode();
    this.updateStats();
  },

  selectMode(mode) {
    this.currentMode = mode;
    document.querySelectorAll('.mode-tab').forEach(t => {
      t.classList.toggle('active', t.dataset.mode === mode);
    });
    document.querySelectorAll('.mode-panel').forEach(p => {
      p.style.display = p.id === `panel-${mode}` ? 'block' : 'none';
    });

    // Init modules if needed
    if (mode === 'mindmap') MindMap.render(this.currentLevel);
    if (mode === 'flashcard') FlashCard.init(this.currentLevel, this.currentCategory);
    if (mode === 'patterns') Patterns.render(this.currentLevel);
    if (mode === 'browse') Browse.render(this.currentLevel);
    if (mode === 'quiz') Quiz.init();
    if (mode === 'grammar') Grammar.render(this.currentLevel);
  },

  renderCurrentMode() {
    switch (this.currentMode) {
      case 'mindmap': MindMap.render(this.currentLevel); break;
      case 'flashcard': FlashCard.init(this.currentLevel, this.currentCategory); break;
      case 'patterns': Patterns.render(this.currentLevel); break;
      case 'browse': Browse.render(this.currentLevel); break;
      case 'quiz': Quiz.init(); break;
      case 'grammar': Grammar.render(this.currentLevel); break;
    }
  },

  getCurrentData() {
    return this.data[this.currentLevel];
  },

  getAllWords(level) {
    const d = this.data[level];
    if (!d) return [];
    return d.categories.flatMap(cat =>
      cat.words.map(w => ({ ...w, category: cat.name, category_vi: cat.name_vi, hsk_level: level }))
    );
  },

  markMastered(wordId) {
    this.masteredWords.add(wordId);
    localStorage.setItem('hsk_mastered', JSON.stringify([...this.masteredWords]));
    this.updateStats();
  },

  updateStats() {
    const total = this.getAllWords(this.currentLevel).length;
    const mastered = this.getAllWords(this.currentLevel)
      .filter(w => this.masteredWords.has(w.hanzi)).length;
    const pct = total > 0 ? Math.round(mastered / total * 100) : 0;
    const el = document.getElementById('progress-text');
    const bar = document.getElementById('progress-bar');
    if (el) el.textContent = `HSK${this.currentLevel}: ${mastered}/${total} từ (${pct}%)`;
    if (bar) bar.style.width = pct + '%';
  },

  handleSearch(query) {
    if (!query.trim()) {
      this.renderCurrentMode();
      return;
    }
    const q = query.toLowerCase();
    const results = [];
    for (let lvl = 1; lvl <= 4; lvl++) {
      this.getAllWords(lvl).forEach(w => {
        if (w.hanzi.includes(q) || w.pinyin.toLowerCase().includes(q) ||
          w.vi.toLowerCase().includes(q) || w.en.toLowerCase().includes(q)) {
          results.push({ ...w, hsk_level: lvl });
        }
      });
    }
    Browse.renderResults(results, query);
    // Switch to browse mode to show results
    document.querySelectorAll('.mode-tab').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.mode-panel').forEach(p => p.classList.remove('active'));
    document.querySelector('[data-mode="browse"]')?.classList.add('active');
    document.getElementById('panel-browse')?.classList.add('active');
  }
};

// ============ MINDMAP MODULE ============
const MindMap = {
  expanded: new Set(),

  render(level) {
    const container = document.getElementById('mindmap-container');
    if (!container) return;
    const data = App.data[level];
    if (!data) { container.innerHTML = '<p class="no-data">Không có dữ liệu</p>'; return; }

    let html = `<div class="mindmap-root">
      <div class="mindmap-center" style="background: var(--accent-color)">
        <span class="mindmap-level-label">HSK${level}</span>
        <span class="mindmap-total">${data.total} từ</span>
      </div>
      <div class="mindmap-branches">`;

    data.categories.forEach((cat, i) => {
      const isExp = this.expanded.has(`${level}-${i}`);
      html += `
        <div class="mindmap-branch ${isExp ? 'expanded' : ''}">
          <div class="mindmap-node category-node" onclick="MindMap.toggleCategory(${level}, ${i})" style="--idx:${i}">
            <span class="node-icon">${cat.icon}</span>
            <span class="node-name">${cat.name_vi}</span>
            <span class="node-count">${cat.words.length}</span>
            <span class="node-toggle">${isExp ? '▲' : '▼'}</span>
          </div>
          <div class="word-cloud ${isExp ? 'show' : ''}">
            ${cat.words.map(w => `
              <div class="word-chip ${App.masteredWords.has(w.hanzi) ? 'mastered' : ''}"
                   onclick="MindMap.showWordDetail('${w.hanzi.replace(/'/g, "\\'")}', ${level})">
                <span class="chip-hanzi">${w.hanzi}</span>
                ${App.showPinyin ? `<span class="chip-pinyin">${w.pinyin}</span>` : ''}
                <span class="chip-audio" onclick="event.stopPropagation(); Speech.speak('${w.hanzi.replace(/'/g, "\\'")}', 'zh-CN')">🔊</span>
              </div>`).join('')}
          </div>
        </div>`;
    });

    html += `</div></div>`;
    container.innerHTML = html;
  },

  toggleCategory(level, idx) {
    const key = `${level}-${idx}`;
    if (this.expanded.has(key)) this.expanded.delete(key);
    else this.expanded.add(key);
    this.render(level);
  },

  showWordDetail(hanzi, level) {
    const words = App.getAllWords(level);
    const word = words.find(w => w.hanzi === hanzi);
    if (!word) return;
    WordModal.show(word);
  }
};

// ============ FLASHCARD MODULE ============
const FlashCard = {
  queue: [],
  currentIdx: 0,
  isFlipped: false,
  mode: 'hanzi', // hanzi | pinyin | meaning

  init(level, category) {
    let words = App.getAllWords(level);
    if (category) words = words.filter(w => w.category === category);
    // Shuffle
    this.queue = words.sort(() => Math.random() - 0.5);
    this.currentIdx = 0;
    this.isFlipped = false;
    this.render();
  },

  render() {
    const container = document.getElementById('flashcard-container');
    if (!container || this.queue.length === 0) {
      if (container) container.innerHTML = '<p class="no-data">Không có từ nào để ôn luyện!</p>';
      return;
    }
    const word = this.queue[this.currentIdx];
    const progress = `${this.currentIdx + 1} / ${this.queue.length}`;
    const pct = ((this.currentIdx + 1) / this.queue.length * 100).toFixed(0);

    container.innerHTML = `
      <div class="fc-header">
        <div class="fc-progress-bar"><div class="fc-progress-fill" style="width:${pct}%"></div></div>
        <div class="fc-counter">${progress}</div>
        <div class="fc-mode-toggle">
          <button class="fc-mode-btn ${this.mode === 'hanzi' ? 'active' : ''}" onclick="FlashCard.setMode('hanzi')">汉字</button>
          <button class="fc-mode-btn ${this.mode === 'pinyin' ? 'active' : ''}" onclick="FlashCard.setMode('pinyin')">Pinyin</button>
          <button class="fc-mode-btn ${this.mode === 'meaning' ? 'active' : ''}" onclick="FlashCard.setMode('meaning')">Nghĩa</button>
        </div>
      </div>
      <div class="flashcard ${this.isFlipped ? 'flipped' : ''}" onclick="FlashCard.flip()">
        <div class="card-inner">
          <div class="card-front">
            ${this.getFront(word)}
          </div>
          <div class="card-back">
            ${this.getBack(word)}
          </div>
        </div>
        <div class="flip-hint">${this.isFlipped ? '' : '👆 Nhấn để lật thẻ'}</div>
      </div>
      <div class="fc-actions ${this.isFlipped ? 'show' : ''}">
        <button class="fc-btn again" onclick="FlashCard.answer('again')">🔄 Học lại</button>
        <button class="fc-btn hard" onclick="FlashCard.answer('hard')">😓 Khó</button>
        <button class="fc-btn easy" onclick="FlashCard.answer('easy')">✅ Thuộc rồi</button>
      </div>
      <div class="fc-nav">
        <button class="fc-nav-btn" onclick="FlashCard.prev()" ${this.currentIdx === 0 ? 'disabled' : ''}>‹ Trước</button>
        <button class="fc-nav-btn" onclick="FlashCard.shuffle()">🔀 Xáo bài</button>
        <button class="fc-nav-btn" onclick="FlashCard.next()" ${this.currentIdx === this.queue.length - 1 ? 'disabled' : ''}>Tiếp ›</button>
      </div>`;
  },

  getFront(word) {
    if (this.mode === 'hanzi') return `<div class="card-hanzi" onclick="event.stopPropagation(); Speech.speak('${word.hanzi.replace(/'/g, "\\\'")}', 'zh-CN')">${word.hanzi} 🔊</div><div class="card-pos">${word.pos}</div>`;
    if (this.mode === 'pinyin') return `<div class="card-pinyin-big" onclick="event.stopPropagation(); Speech.speak('${word.hanzi.replace(/'/g, "\\\'")}', 'zh-CN')">${word.pinyin} 🔊</div>`;
    return `<div class="card-meaning">${word.vi}</div><div class="card-meaning-en">${word.en}</div>`;
  },

  getBack(word) {
    return `
      <div class="card-back-content">
        <div class="back-hanzi">${word.hanzi}</div>
        <div class="back-pinyin">${word.pinyin}</div>
        <div class="back-vi">${word.vi}</div>
        <div class="back-en">${word.en}</div>
        ${word.examples && word.examples[0] ? `
          <div class="back-example" onclick="event.stopPropagation(); Speech.speak('${word.examples[0].s.replace(/'/g, "\\'")}', 'zh-CN')">
            <div class="ex-sentence">${word.examples[0].s} 🔊</div>
            <div class="ex-pinyin">${word.examples[0].p}</div>
            <div class="ex-vi">${word.examples[0].vi}</div>
          </div>` : ''}
      </div>`;
  },

  flip() { this.isFlipped = !this.isFlipped; this.render(); },
  setMode(mode) { this.mode = mode; this.isFlipped = false; this.render(); },
  prev() { if (this.currentIdx > 0) { this.currentIdx--; this.isFlipped = false; this.render(); } },
  next() { if (this.currentIdx < this.queue.length - 1) { this.currentIdx++; this.isFlipped = false; this.render(); } },
  shuffle() { this.queue.sort(() => Math.random() - 0.5); this.currentIdx = 0; this.isFlipped = false; this.render(); },

  answer(rating) {
    const word = this.queue[this.currentIdx];
    if (rating === 'easy') {
      App.markMastered(word.hanzi);
    }
    if (rating === 'again') {
      // Move back to end of queue
      const w = this.queue.splice(this.currentIdx, 1)[0];
      this.queue.push(w);
      if (this.currentIdx >= this.queue.length) this.currentIdx = 0;
    } else {
      this.next();
    }
    this.isFlipped = false;
    this.render();
  }
};

// ============ PATTERNS MODULE ============
const Patterns = {
  render(level) {
    const container = document.getElementById('patterns-container');
    if (!container) return;
    const data = App.data[level];
    if (!data || !data.patterns) { container.innerHTML = '<p class="no-data">Không có mẫu câu.</p>'; return; }

    let html = `<div class="patterns-list">`;
    data.patterns.forEach((p, i) => {
      html += `
        <div class="pattern-card" style="--idx:${i}">
          <div class="pattern-title">${p.title}</div>
          <div class="pattern-formula">${p.pattern}</div>
          <div class="pattern-example" onclick="Speech.speak('${p.example.replace(/'/g, "\\'")}', 'zh-CN')">
            <div class="p-example-cn">${p.example} 🔊</div>
            <div class="p-example-vi">${p.example_vi}</div>
          </div>
          ${p.note ? `<div class="pattern-note">💡 ${p.note}</div>` : ''}
        </div>`;
    });
    html += `</div>`;
    container.innerHTML = html;
  }
};

// ============ GRAMMAR MODULE ============
const Grammar = {
  render(level) {
    const container = document.getElementById('grammar-container');
    if (!container) return;

    if (typeof HSK_GRAMMAR_DATA === 'undefined') {
      container.innerHTML = '<p class="no-data">Đang tải dữ liệu ngữ pháp...</p>';
      return;
    }

    const levelData = HSK_GRAMMAR_DATA.find(d => d.level === level);
    if (!levelData) {
      container.innerHTML = '<p class="no-data">Dữ liệu ngữ pháp cho HSK' + level + ' đang được cập nhật.</p>';
      return;
    }

    let html = `
      <div class="grammar-level-group">
        <h3 style="color:${levelData.color}">📚 Ngữ pháp HSK ${level}</h3>
        <div class="grammar-list">`;

    levelData.points.forEach(point => {
      html += `
        <div class="grammar-card">
          <div class="grammar-card-header">
            <div class="grammar-title">${point.title}</div>
            <div class="grammar-structure">${point.structure}</div>
          </div>
          <div class="grammar-explanation">${point.explanation}</div>
          <div class="grammar-examples">
            ${point.examples.map(ex => `
              <div class="g-ex-item" onclick="Speech.speak('${ex.hanzi.replace(/'/g, "\\\'")}', 'zh-CN')">
                <div class="g-ex-cn">${ex.hanzi} 🔊</div>
                <div class="g-ex-pinyin">${ex.pinyin}</div>
                <div class="g-ex-vi">${ex.vi}</div>
              </div>
            `).join('')}
          </div>
        </div>`;
    });

    html += `</div></div>`;
    container.innerHTML = html;
  }
};

// ============ BROWSE MODULE ============
const Browse = {
  render(level) {
    const data = App.data[level];
    const container = document.getElementById('panel-browse');
    if (!container || !data) return;
    let html = `<div class="browse-header">
      <h3>HSK${level} — Duyệt từ vựng theo chủ đề</h3>
    </div>`;
    data.categories.forEach(cat => {
      html += `<div class="browse-section">
        <div class="browse-cat-header">${cat.icon} ${cat.name_vi} <span class="cat-cn">${cat.name}</span></div>
        <div class="browse-words">`;
      cat.words.forEach(w => {
        const mastered = App.masteredWords.has(w.hanzi);
        html += `<div class="browse-word-row ${mastered ? 'mastered' : ''}" onclick="WordModal.show(${JSON.stringify({ ...w }).replace(/"/g, '&quot;')})">
          <span class="bw-hanzi">${w.hanzi}</span>
          <span class="bw-pinyin">${w.pinyin}</span>
          <span class="bw-vi">${w.vi}</span>
          <span class="bw-pos">${w.pos}</span>
          <span class="bw-audio" onclick="event.stopPropagation(); Speech.speak('${w.hanzi.replace(/'/g, "\\'")}', 'zh-CN')">🔊</span>
          ${mastered ? '<span class="bw-mastered">✅</span>' : ''}
        </div>`;
      });
      html += `</div></div>`;
    });
    const browsePanel = document.getElementById('panel-browse');
    if (browsePanel) browsePanel.innerHTML = html;
  },

  renderResults(results, query) {
    const browsePanel = document.getElementById('panel-browse');
    if (!browsePanel) return;
    let html = `<div class="browse-header"><h3>🔍 Kết quả tìm kiếm: "${query}" (${results.length} từ)</h3></div>
    <div class="browse-words">`;
    results.forEach(w => {
      html += `<div class="browse-word-row" onclick="WordModal.show(${JSON.stringify({ ...w }).replace(/"/g, '&quot;')})">
        <span class="bw-level hsk${w.hsk_level}">HSK${w.hsk_level}</span>
        <span class="bw-hanzi">${w.hanzi}</span>
        <span class="bw-pinyin">${w.pinyin}</span>
        <span class="bw-vi">${w.vi}</span>
      </div>`;
    });
    html += `</div>`;
    browsePanel.innerHTML = html;
  }
};

// ============ WORD MODAL MODULE ============
const WordModal = {
  show(word) {
    const modal = document.getElementById('word-modal');
    const content = document.getElementById('modal-content');
    if (!modal || !content) return;

    const mastered = App.masteredWords.has(word.hanzi);
    content.innerHTML = `
      <div class="modal-word-header">
        <div class="modal-hanzi" onclick="Speech.speak('${word.hanzi.replace(/'/g, "\\'")}', 'zh-CN')">${word.hanzi} 🔊</div>
        <div class="modal-pinyin">${word.pinyin}</div>
        <div class="modal-badges">
          <span class="badge-pos">${word.pos}</span>
          <span class="badge-level hsk${word.hsk_level || App.currentLevel}">HSK${word.hsk_level || App.currentLevel}</span>
          <span class="badge-cat">${word.category_vi || ''}</span>
        </div>
      </div>
      <div class="modal-meanings">
        <div class="modal-vi">🇻🇳 ${word.vi}</div>
        <div class="modal-en">🇬🇧 ${word.en}</div>
      </div>
      ${word.examples && word.examples.length > 0 ? `
      <div class="modal-examples">
        <h4>📝 Câu ví dụ</h4>
        ${word.examples.map(ex => `
          <div class="modal-example" onclick="Speech.speak('${ex.s.replace(/'/g, "\\'")}', 'zh-CN')">
            <div class="ex-cn">${ex.s} 🔊</div>
            <div class="ex-py">${ex.p}</div>
            <div class="ex-vn">${ex.vi}</div>
          </div>`).join('')}
      </div>` : ''}
      <div class="modal-actions">
        <button class="modal-btn ${mastered ? 'unmark' : 'mark'}"
          onclick="WordModal.toggleMastered('${word.hanzi}')">
          ${mastered ? '↩️ Bỏ đánh dấu' : '✅ Đánh dấu thuộc'}
        </button>
        <button class="modal-btn flashcard-btn"
          onclick="FlashCard.init(${word.hsk_level || App.currentLevel}, '${word.category}'); App.selectMode('flashcard'); WordModal.close()">
          🃏 Ôn chủ đề này
        </button>
      </div>`;
    modal.classList.add('show');
  },

  toggleMastered(hanzi) {
    if (App.masteredWords.has(hanzi)) {
      App.masteredWords.delete(hanzi);
      localStorage.setItem('hsk_mastered', JSON.stringify([...App.masteredWords]));
    } else {
      App.markMastered(hanzi);
    }
    App.updateStats();
    document.getElementById('word-modal').classList.remove('show');
  },

  close() {
    document.getElementById('word-modal').classList.remove('show');
  }
};

// ================= QUIZ MODULE =================
const Quiz = {
  questions: [],
  currentIdx: 0,
  score: 0,
  isAnswering: false,

  init() {
    this.showSection('setup');
  },

  showSection(id) {
    ['setup', 'game', 'result'].forEach(s => {
      const el = document.getElementById(`quiz-${s}`);
      if (el) el.classList.toggle('hidden', s !== id);
    });
  },

  start() {
    const allWords = App.getAllWords(App.currentLevel);
    if (allWords.length < 4) {
      alert("Không đủ từ vựng để tạo Quiz cho cấp độ này!");
      return;
    }
    this.questions = this.generateQuestions(allWords, 10);
    this.currentIdx = 0;
    this.score = 0;
    this.showSection('game');
    this.renderQuestion();
  },

  generateQuestions(pool, count) {
    const shuffled = [...pool].sort(() => 0.5 - Math.random());
    const finalCount = Math.min(count, pool.length);
    return shuffled.slice(0, finalCount).map(word => {
      const type = Math.floor(Math.random() * 3);
      const alternatives = pool.filter(w => w.hanzi !== word.hanzi).sort(() => 0.5 - Math.random()).slice(0, 3);
      let question, answer, options;
      if (type === 0) {
        question = word.hanzi; answer = word.vi;
        options = this.shuffle([word.vi, ...alternatives.map(a => a.vi)]);
      } else if (type === 1) {
        question = word.vi; answer = word.hanzi;
        options = this.shuffle([word.hanzi, ...alternatives.map(a => a.hanzi)]);
      } else {
        question = word.pinyin; answer = word.hanzi;
        options = this.shuffle([word.hanzi, ...alternatives.map(a => a.hanzi)]);
      }
      return { question, answer, options, type, word };
    });
  },

  shuffle(arr) { return arr.sort(() => 0.5 - Math.random()); },

  renderQuestion() {
    const q = this.questions[this.currentIdx];
    const qBox = document.getElementById('quiz-question-box');
    const oBox = document.getElementById('quiz-options');
    const sBox = document.getElementById('quiz-stats');
    if (!qBox || !oBox || !sBox) return;
    this.isAnswering = false;
    document.getElementById('quiz-feedback').textContent = '';
    sBox.textContent = `Câu hỏi: ${this.currentIdx + 1}/${this.questions.length} | Điểm: ${this.score}`;

    // Add TTS for type 0 (Hanzi) and type 2 (Pinyin)
    if (q.type === 0 || q.type === 2) {
      const speakText = q.type === 0 ? q.question : q.word.hanzi;
      qBox.innerHTML = `${q.question} <span class="quiz-audio" onclick="Speech.speak('${speakText.replace(/'/g, "\\\'")}', 'zh-CN')">🔊</span>`;
    } else {
      qBox.textContent = q.question;
    }

    qBox.className = `quiz-question ${q.type === 1 ? 'vi-question' : ''}`;
    oBox.innerHTML = q.options.map(opt => `
      <div class="quiz-option" onclick="Quiz.checkAnswer('${opt.replace(/'/g, "\\\'")}')">${opt}</div>
    `).join('');
  },

  checkAnswer(choice) {
    if (this.isAnswering) return;
    this.isAnswering = true;
    const q = this.questions[this.currentIdx];
    const options = document.querySelectorAll('.quiz-option');
    const feedback = document.getElementById('quiz-feedback');
    options.forEach(opt => {
      opt.classList.add('disabled');
      if (opt.textContent === q.answer) opt.classList.add('correct');
      if (opt.textContent === choice && choice !== q.answer) opt.classList.add('wrong');
    });
    if (choice === q.answer) {
      this.score++; feedback.textContent = '🎉 Chính xác!'; feedback.style.color = '#4CAF50';
    } else {
      feedback.textContent = `❌ Sai rồi! Đáp án là: ${q.answer}`;
      feedback.style.color = '#f44336';
    }
    setTimeout(() => {
      this.currentIdx++;
      if (this.currentIdx < this.questions.length) this.renderQuestion();
      else this.showResult();
    }, 1500);
  },

  showResult() {
    this.showSection('result');
    document.getElementById('result-score').textContent = `${this.score}/${this.questions.length}`;
  },

  restart() { this.start(); }
};

// ================= SPEECH MODULE =================
const Speech = {
  speak(text, lang = 'zh-CN') {
    if (!window.speechSynthesis) return;
    // Cancel any ongoing speech
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang;
    utterance.rate = 0.9; // Slightly slower for better clarity
    window.speechSynthesis.speak(utterance);
  }
};

window.addEventListener('DOMContentLoaded', () => App.init());
